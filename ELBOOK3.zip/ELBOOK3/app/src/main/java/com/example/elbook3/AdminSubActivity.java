package com.example.elbooks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.elbook3.R;

public class AdminSubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminsub);

        /*TextView textView = findViewById(R.id.textView);*/
        /*textView.setText("こんにちは");*/
    }
}